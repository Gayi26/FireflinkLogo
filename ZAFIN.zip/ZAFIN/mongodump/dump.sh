#!/bin/bash

set -euo pipefail

# MongoDB container name
CONTAINER_NAME="mongodb"

# Backup directory
BACKUP_DIR="/home/onprem/mongobackup"

# Log file
LOG_FILE="/var/log/mongo_backup.log"

# Timestamp
DATE_FORMAT=$(date +"%Y-%m-%d_%H-%M-%S")

# Backup files
BACKUP_FILE1="${BACKUP_DIR}/mongodb_backup_LIC27000_${DATE_FORMAT}.archive.gz"
BACKUP_FILE2="${BACKUP_DIR}/mongodb_backup_AUTH_${DATE_FORMAT}.archive.gz"

# Create backup directory
mkdir -p "$BACKUP_DIR"

echo "$(date): Starting MongoDB backup..." >> "$LOG_FILE"

# Check if container is running
if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo "$(date): ERROR - Container '${CONTAINER_NAME}' is not running." >> "$LOG_FILE"
    exit 1
fi

echo "$(date): Backing up optimize_LIC1032..." >> "$LOG_FILE"

docker exec "$CONTAINER_NAME" mongodump \
    --username=mongo \
    --password=mongo \
    --authenticationDatabase=admin \
    --db=optimize_LIC1032 \
    --archive \
    --gzip > "$BACKUP_FILE1"

# Validate gzip archive
gzip -t "$BACKUP_FILE1"

echo "$(date): Backup completed successfully: $BACKUP_FILE1" >> "$LOG_FILE"

# Backup optimize_auth database
echo "$(date): Backing up optimize_auth..." >> "$LOG_FILE"

docker exec "$CONTAINER_NAME" mongodump \
    --username=mongo \
    --password=mongo \
    --authenticationDatabase=admin \
    --db=optimize_auth \
    --archive \
    --gzip > "$BACKUP_FILE2"

# Validate gzip archive
gzip -t "$BACKUP_FILE2"

echo "$(date): Backup completed successfully: $BACKUP_FILE2" >> "$LOG_FILE"

# Remove backups older than 3 days
find "$BACKUP_DIR" -type f -name "*.gz" -mtime +3 -delete

echo "$(date): Old backups older than 3 days removed." >> "$LOG_FILE"

echo "$(date): MongoDB backup job completed successfully." >> "$LOG_FILE"

exit 0